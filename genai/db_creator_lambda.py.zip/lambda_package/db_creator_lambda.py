import json
import psycopg2
import cfnresponse # AWS-provided library for custom resources
import os
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_db_credentials(secret_arn):
    """
    Placeholder for fetching DB credentials if they were stored in Secrets Manager.
    For this example, we assume they are passed directly or via environment variables
    set by Pulumi when configuring the Lambda.
    However, in a more production-ready setup, the Lambda might fetch the
    master password from Secrets Manager using its execution role.
    """
    # For this example, we'll assume Pulumi passes them as environment variables
    # or directly in the event.
    # If using Secrets Manager:
    # import boto3
    # client = boto3.client('secretsmanager')
    # response = client.get_secret_value(SecretId=secret_arn)
    # secret = json.loads(response['SecretString'])
    # return secret['username'], secret['password']
    pass


def create_database(db_host, db_port, admin_user, admin_password, admin_db_name, new_db_name, new_db_owner):
    conn = None
    try:
        logger.info(f"Attempting to connect to host {db_host} on port {db_port} with user {admin_user} to database {admin_db_name}")
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            user=admin_user,
            password=admin_password,
            database=admin_db_name, # Connect to an existing DB (e.g., the initial one)
            connect_timeout=10,
            sslmode='require' # Or 'prefer', adjust as per your RDS SSL config
        )
        conn.autocommit = True # Or handle transactions explicitly
        cur = conn.cursor()

        # Check if database already exists
        cur.execute("SELECT 1 FROM pg_database WHERE datname = %s;", (new_db_name,))
        exists = cur.fetchone()

        if not exists:
            logger.info(f"Database '{new_db_name}' does not exist. Creating...")
            # Use sql.SQL for safe identifier quoting if needed, though simple names are fine here
            cur.execute(f"CREATE DATABASE {new_db_name};") # Be cautious with direct string formatting for DB names if they can be complex
            logger.info(f"Database '{new_db_name}' created successfully.")
            if new_db_owner:
                 # The admin_user (master user) will be the owner by default if it creates the DB.
                 # This step is redundant if new_db_owner is the same as admin_user.
                 # If you wanted a *different* owner (and that user exists), you'd use:
                 # cur.execute(f"ALTER DATABASE {new_db_name} OWNER TO {new_db_owner};")
                 # logger.info(f"Set owner of '{new_db_name}' to '{new_db_owner}'.")
                 pass # Master user is owner by default
        else:
            logger.info(f"Database '{new_db_name}' already exists.")

        cur.close()
        return True
    except Exception as e:
        logger.error(f"Error creating database '{new_db_name}': {str(e)}")
        raise e
    finally:
        if conn:
            conn.close()

def lambda_handler(event, context):
    request_type = event['RequestType']
    response_data = {}
    physical_resource_id = event.get('PhysicalResourceId', context.log_stream_name)

    try:
        props = event['ResourceProperties']
        db_host = props['DbHost']
        db_port = int(props.get('DbPort', 5432))
        admin_user = props['AdminUser']
        admin_password = props['AdminPassword'] # Passed directly for simplicity here
        admin_db_name = props['AdminDbName']   # The initial DB to connect to
        new_db_name = props['NewDbName']
        new_db_owner = props.get('NewDbOwner', admin_user) # Defaults to admin_user

        if request_type == 'Create' or request_type == 'Update':
            logger.info(f"RequestType: {request_type}. Creating/Updating database '{new_db_name}'.")
            create_database(db_host, db_port, admin_user, admin_password, admin_db_name, new_db_name, new_db_owner)
            response_data['Message'] = f"Database '{new_db_name}' operation successful."
            # The physical resource ID should be stable for updates if the logical ID doesn't change
            # and the identifying properties (like NewDbName) are the same.
            physical_resource_id = f"{new_db_name}-db"


        elif request_type == 'Delete':
            # Implement deletion logic if necessary (e.g., DROP DATABASE)
            # Be very careful with automated DROP DATABASE in production!
            # For this example, we'll make deletion a no-op to avoid accidental data loss.
            logger.info(f"RequestType: Delete. Database '{new_db_name}' deletion is a no-op in this example.")
            response_data['Message'] = f"Database '{new_db_name}' deletion skipped."

        cfnresponse.send(event, context, cfnresponse.SUCCESS, response_data, physical_resource_id)
    except Exception as e:
        logger.error(f"Failed to process event: {str(e)}")
        cfnresponse.send(event, context, cfnresponse.FAILED, {"Error": str(e)}, physical_resource_id)